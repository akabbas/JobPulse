# AI Services module for JobPulse
# Integrates GPT-5 and other AI capabilities for enhanced job market analysis
